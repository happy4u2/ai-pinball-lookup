import { GetCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import { dynamoDocClient } from "./dynamoClient.js";

const TABLE_NAME =
  process.env.METADATA_TABLE_NAME || "pinball_machine_metadata";

export async function getMetadata(machineId) {
  const result = await dynamoDocClient.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: { machineId },
    }),
  );

  return result.Item || null;
}

export async function saveMetadata(record) {
  const now = new Date().toISOString();

  const item = {
    ...record,
    updatedAt: now,
    createdAt: record.createdAt || now,
  };

  await dynamoDocClient.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: item,
    }),
  );

  return item;
}
